package food;

import java.util.ArrayList;

import com.bwf.jni.Consoles;
import com.bwf.jni.Consoles.*;
public class Food {
	
	private int range;	//ȷ��ʳ��ķ�Χ
	public int foodX;
	public int foodY;
	public final String P = "��";
	public final int baseX = 5;	//ȷ����ʼ�ο�����
	public final int baseY = 5;
	public ArrayList<Position> positions;
	
	public Food (){}
	public Food (int range , ArrayList<Position> positions ){	
		this.range = range;
		this.positions = positions;
	}
	
	public Position printFood(){
		int[] arr = new int[2];
		Position foodPosition = null;
		int count = 0;
		
		while( count==0 ){
			foodX = (int)(Math.random()*((range-2)*2-1) + baseX+2);
			foodY = (int)(Math.random()*(range-2) + baseY+1);
			
			foodPosition = new Position( foodX , foodY );
			
			for( Position p : positions){
				if( p.equals(foodPosition) ){
					count++ ;
				}
			}
		}
		
		boolean b = true;
		while(b){
			if(foodX%2==0){
				b = true;
				foodX = (int)(Math.random()*((range-2)*2-1) + baseX+2);
			}else 
				b = false;
		}
		Consoles.gotoXY(foodX,foodY);
		System.out.println(P);
		Position position = new Position(foodX,foodY);
			
		return position;	
	}	
}
