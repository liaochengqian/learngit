package food;

import java.util.ArrayList;

import com.bwf.jni.Consoles;
import com.bwf.jni.Consoles.Position;

public class FoodTask implements Runnable {
	private Food food;
	private int range;
	public Position pos;
	public static boolean setOver;
	//private Snack snack ;
	
	public static final int SLEEP = 500;
	public FoodTask (Food food,Position pos ){
		this.food = food;
		this.pos = pos;
		//this.snack = snack;
	}
	
	@Override
	public void run() {
		try {
			while(true){
				Consoles.gotoXY(pos.x,pos.y);
				System.out.println("  ");
				Thread.sleep(SLEEP);
				Consoles.gotoXY(pos.x,pos.y);
				System.out.println("��");
				setOver = true ;
				Thread.sleep(SLEEP);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}	
	}
}
