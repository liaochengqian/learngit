package wall;

import com.bwf.jni.Consoles;

public class Wall {	 
	//private int X;
	//private int Y;
	private int range;
	final public static int baseX = 5;	//ȷ����ʼ�ο�����
	final public static int baseY = 5;
	final public String S1= "��";
	final public String S2= "��";
	final public String S3= "��";
	final public String S4= "��";
	final public String S5= "��";
	final public String S6= "��";
	final public String S7= " ";
	
	
	public Wall(){}
	public Wall(int range){	
		this.range = range;
	}
	//���Գ�ʼ�ο����궨λ
	public void gotoXY(){
		Consoles.gotoXY(baseX,baseY);
	}
	public void gotoXY(int x,int y){
		Consoles.gotoXY(baseX+x,baseY+y);
	}
	//��ӡǽ
	public void printWall(){
		Consoles.clearScreen();
		Consoles.gotoXY((5+range)/2,3);
		System.out.println("̰   ��   ��   ��   ս");
		gotoXY(0,0);
		printLine(S1,S2,S3,range);
		for(int i = 1 ; i < range-1;i++){
			Consoles.gotoXY(baseX,baseY+i);
			printLine(S4,S4,S7,(range-1)*2);
		}
		Consoles.gotoXY(baseX,baseY+range-1);	
		printLine(S5,S6,S3,range);	
	}
	
	//��ӡһ��
	public void printLine(String s1,String s2,String s3, int range){
		String s = "";
		
		for(int i = 0; i < range-2;i++){
			s = s + s3;
		}
		System.out.println(s1+s+s2);
	}



	public int getRange() {
		return range;
	}
	public void setRange(int range) {
		this.range = range;
	}
}