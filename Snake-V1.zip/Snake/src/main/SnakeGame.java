package main;
import snake.Snake;
import wall.Wall;

import java.util.ArrayList;

import com.bwf.jni.*;
import com.bwf.jni.Consoles.Position;

public class SnakeGame {

	public Wall wall;		
	public Snake snake;	
	
	public SnakeGame(int wallRange, ArrayList<Position> position, int direction ) {
		wall = new Wall(wallRange);
		snake = new Snake( position, wallRange - 2, direction );
	}

	// 开始贪吃蛇游戏
	public void start() throws InterruptedException {

		wall.printWall();
		snake.playGame();
		
	}
	
	/*
	public boolean isValide(ArrayList<Position> position, int range) {
		// 1. 蛇的每节必须在墙内
		if ( !isInRange(position, range) ) {
			return false;
		}
		return true;
	}
	
	//判断蛇的位置是否都出现在墙内
	public boolean isInRange(ArrayList<Position> position, int range) {
		for (Position p : position) {
			if (p.x < 0 || p.x >= range || p.y < 0 || p.y >= range) {
				return false;
			}
		}
		return true;
	}
	/*
	public boolean hasSameNode(int[][] positions) {
		// 从第 0 节开始，每节与其后的所有节的位置进行比较
		for (int i = 0; i < positions.length - 1; i++) {
			for (int j = i + 1; j < positions.length; j++) {
				if ((positions[i][0] == positions[j][0]) &&
					(positions[i][1] == positions[j][1])) {
					return true;  // 有两节位置相同
				}
			}
		}
		return false;  // 没有任意两节位置相同
	}

	public boolean isContinuous( ArrayList<Position> position) {
		// 从第 1 节开始，每一节必须与前一节相连
		for (int i = 0; i < position.size()-1; i++) {
			// 横坐标相同时，则纵坐标只能相差1
			if (position.get(i).x == position.get(i-1).x) {  
				if ((positions[i][1] != positions[i - 1][1] + 1) &&
					(positions[i][1] != positions[i - 1][1] - 1)) {
					return false;
				}
			// 纵坐标相同时，则横坐标只能相差1
			} else if (positions[i][1] == positions[i - 1][1]) {
				if ((positions[i][0] != positions[i - 1][0] + 1) &&
					(positions[i][0] != positions[i - 1][0] - 1)) {
						return false;
				}
			}
		}
		return true;
	}
	*/
}
