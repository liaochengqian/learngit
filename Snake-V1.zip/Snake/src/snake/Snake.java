package snake;

import com.bwf.jni.*;
import com.bwf.jni.Consoles.Position;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.concurrent.locks.*;
import food.*;
import wall.*;

public class Snake {

	public static final String HEAD = "◎";		
	public static final String BODY = "⊙";		
	public static final String END = "☆";		
	public static final int START_X = Wall.baseX + 2;	
	public static final int START_Y = Wall.baseY + 1;	
	
	// 变量
	public int range;                       
	public int speed = 500;	               
	public int speedCount = 50;	                           
	public int direction;                   
	public FoodTask FoodTask = null;  
	public Thread threadFood = null;                
	public boolean isAlive = true;        
	public Food food;

	public Lock lock = new ReentrantLock();	           
	public Condition condition = lock.newCondition();	

	public ArrayList<Position> positions;
	public int size;

	public Snake( ArrayList<Position> positions, int range, int direction ) {
		this.positions = positions;
		this.range = range;
		this.direction = direction;
		this.size = positions.size();
	}

	// 开始游戏
	public void playGame() {
		// 隐藏光标
		Consoles.hideCursor();

		// 初始化蛇画面
		initView();
		// 游戏没有结束，蛇不停前进
		while ( isAlive ) {

			if (threadFood == null) {
				food = new Food( range , positions );
				FoodTask = new FoodTask( food , positions.get(0) );//此处有问题
				threadFood = new Thread(FoodTask);
				threadFood.start();
		
				
				lock.lock();	// 加锁
				try {
					while (!FoodTask.setOver) {
		
					//	condition.await();	
					}
				} finally {
					lock.unlock();	// 解锁
				}
			
			}
		
			oneStep();
			
		}
		

		if (threadFood != null) {
			threadFood.interrupt();
			threadFood = null;
			FoodTask = null;
		}
		Consoles.showCursor();

	}

	// 初始化蛇画面
	public void initView() {
		
		gotoXY( positions.get(0) );
		System.out.print(HEAD);
		
		for (int i = 1; i < size - 1; i++) {
			gotoXY( positions.get(i) );
			System.out.print(BODY);
		}

		gotoXY( positions.get(size-1) );
		System.out.print(END);
	}


	public void oneStep() {
		checkKey();
		
		int x = positions.get(0).x, y = positions.get(0).y;
	
		switch (direction) {
		case Consoles.UP:
			y = (y + range - 1) % range;
			break;
		case Consoles.DOWN:
			y = (y + range + 1) % range;
			break;
		case Consoles.LEFT:
			x = (x + range - 1) % range;
			break;
		case Consoles.RIGHT:
			x = (x + range + 1) % range;
			break;
		}

		if (x == food.foodX && y == food.foodY ) {
			eatFood(x, y);
			condition.signalAll();
			return;   

		} else if (ateSelf(x, y)) {
			lock.lock();
			gotoXY(0, range + 4);
			System.out.println("游戏结束。");
			lock.unlock();
			isAlive = false;
			return;
		} else {
	
			push(x, y);
	}
		try {
			Thread.sleep(speed);
		} catch (InterruptedException ex) {	}
		
	}
	
	public void checkKey() {
		int keyValue = Consoles.getPressedKey();
		if (keyValue != Consoles.NONE) {  
			switch (keyValue) {
			case Consoles.UP:    
				direction = Consoles.UP;
				break;
			case Consoles.DOWN:   
				direction = Consoles.DOWN;
				break;
			case Consoles.LEFT:   
				direction = Consoles.LEFT;
				break;
			case Consoles.RIGHT:  // 右箭头
				direction = Consoles.RIGHT;	
				break;
			case 'p':
				while (Consoles.getPressedKey() == Consoles.NONE);
				break;
			case 'q':
				lock.lock();
				gotoXY(1, range + 4);
				System.out.print("确定退出本次游戏吗？(y/n)");
				lock.unlock();
				int answer = 0;
				while ((answer = Consoles.getPressedKey()) == Consoles.NONE);
				if (answer == 'y' || answer == 'Y') {
					isAlive = false;
					return;
				}
				lock.lock();
				gotoXY(1, range + 4);
				System.out.print("                                        ");
				lock.unlock();
			}
		}
	}
	
	public boolean ateSelf(int x, int y) {
		for (Position p : positions) {
			if (p.x == x && p.y == y) {		
				return true;
			}
		}
		return false;	
	}


	public void push(int x, int y) {
		headStep(x, y);
		// 蛇尾前进一步
		tailStep();
		
		positions.remove(size-1);
		positions.add(new Position(x, y));
	}

	
	public void eatFood(int x, int y) {
		headStep(x, y);
		positions.add(new Consoles.Position(x, y));
	
		threadFood.interrupt();
		threadFood = null;	
		FoodTask = null;
	}

	
	public void headStep(int x, int y) {
		lock.lock();
		gotoXY(x, y);
		System.out.print(HEAD);
		gotoXY( positions.get(0) );
		System.out.print(BODY);
		lock.unlock();
	}
	
	public void tailStep() {
		lock.lock();
		gotoXY(positions.get(size -2));
		System.out.print(END);
		gotoXY( positions.get(size - 1) );
		System.out.print("  ");
		lock.unlock();
	}
	
	
	public void gotoXY( int x , int y){
		Consoles.gotoXY( START_X + x * 2, START_Y + y);
	}
	public void gotoXY( Position p ) {
		Consoles.gotoXY(START_X + p.x * 2, START_Y + p.y);
	}
}