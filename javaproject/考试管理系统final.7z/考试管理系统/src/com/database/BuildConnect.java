package com.database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class BuildConnect {
	//�����ӡResultSet�ķ���
	public static void print( ResultSet r) throws SQLException{
		System.out.println(">>>===============��һ��===============<<<");
		while( r.next() ){
			int qno = r.getInt(1);
			String qquestion = r.getString(2);
			System.out.printf("%d\t%s\t\n",qno,qquestion);
		}
	}
	

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//�����׼������
		Scanner scan = new Scanner( System.in );
		//�����������ݿ���Ϣ
		String URL = "jdbc:mysql://localhost/";
		//String URL = "jdbc:mysql://172.31.148.90/";
		String dbBase = "examinationmanagement";
		String dbBaseURL = URL + dbBase;
		String username = "root";
		String passwd = "";
		//��������
		MysqlDatabaseDao dao = new MysqlDatabaseDao(dbBaseURL, username, passwd);
		dao.getConnection();
	
		//��ѯ���ݿ�
		String table = "examinationquestions";
		String sql = "select * from "+ table; // +" where qno=5";
		
		ResultSet result = dao.select( sql );
		
		 print( result );
		 dao.getClose();
	}
}
