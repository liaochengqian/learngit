package com.client;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Deque;

public class SendClientListTask implements Runnable {
	public Deque<Object> transList;
	public Object o;
	public ObjectOutputStream oos;
	
	public SendClientListTask( Deque<Object> transList ,ObjectOutputStream oos ){
		this.transList = transList;
		this.oos = oos;
	}
	
	@Override
	public void run(){
		while (true) {
			
			if( transList.isEmpty() ){
				
				try{
				
					Thread.sleep(500);
					
				} catch (InterruptedException e) {
					
					System.out.println();
				}
					
				}
			
			if( !transList.isEmpty() ){

				o = transList.removeFirst();
				//������o����������
				try {
					oos.writeObject( o );
					oos.flush();
					
				} catch (IOException e) {
					
					System.out.println("�ͻ������˳���");
			}
		}
	}
}
}
