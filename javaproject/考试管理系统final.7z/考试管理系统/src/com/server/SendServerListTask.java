package com.server;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Deque;

public class SendServerListTask implements Runnable {
	/**
	 * 
	 */
	public Deque<Object> sendList;
	public Object o;
	public ObjectOutputStream oos;
	
	public SendServerListTask( Deque<Object> sendList ,ObjectOutputStream oos ){
		this.sendList = sendList;
		this.oos = oos;
	}
	
	@Override
	public void run(){
		
		while( true ){
			if( sendList.isEmpty() ){
				
				try {
					
					Thread.sleep(1000);
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					
			}
			
			if( !sendList.isEmpty() ){
				
			
				o = sendList.removeFirst();
				//������o������������
				try {
					
					oos.writeObject( o );
					
					oos.flush();
					
					Thread.sleep(100);
				} catch (IOException | InterruptedException e) {
					System.out.println("IO�쳣");
				}	
			}
		}
	}
}
