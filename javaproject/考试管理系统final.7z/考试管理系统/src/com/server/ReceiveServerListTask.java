package com.server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.Deque;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ReceiveServerListTask extends Thread {
	public Object o;
	public ObjectInputStream ois;
	public Deque<Object> recvList;
	public Lock lock = new ReentrantLock();
	public Condition cond = lock.newCondition();
	public Socket socket;
	
	public ReceiveServerListTask( Deque<Object> recvList , ObjectInputStream ois , Socket socket){
		this.ois = ois ;
		this.recvList = recvList;
		this.socket = socket;
	}
	
	@Override
	public void run(){
		Object object = null;
		try {
			
			while( ( object = ois.readObject() ) != null ){
				this.o = object ;			 //�����н��ն���	
				recvList.addLast(o);
			}

		} catch (ClassNotFoundException | IOException  e) {
			System.out.println("�ͻ���"  + socket.getInetAddress().getHostAddress() +  "����ɽ���");
			}
		}
}
