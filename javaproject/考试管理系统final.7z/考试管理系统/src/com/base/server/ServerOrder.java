package com.base.server;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.base.client.*;
import com.database.MysqlDatabaseDao;

public class ServerOrder extends Thread {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1884618824619739492L;
	private boolean start = false;
	private Lock startLock = new ReentrantLock();
	private Condition startCond = startLock.newCondition();
	public ArrayList<String> enos = new ArrayList<String>();
	
	public MysqlDatabaseDao dao;
	
	public ServerOrder(MysqlDatabaseDao dao){
		this.dao = dao;
	}
	

	@Override
	public void run(){
		while( true){	
			System.out.println(">===================================="
								+ "==========================================<\n"
								+ "1.�鿴������Ϣ\t 2.�޸ĵ�¼״̬\t 3.��ʼ���� \t 4.�˳�ϵͳ");
			
			
			Scanner input = new Scanner(System.in);
			int order = input.nextInt();
			switch( order ){
			
			case 1:
				try {
					dao.getConnection();
				String sql = "select * from examinee";
				ResultSet result = dao.select( sql );
				//��ȡ���ݿ����ݲ���ֵ
				while( result.next() ){
					enos.add( result.getString("eno") );
					System.out.println("ѧ�ţ�" + result.getString("eno")
										+"������" + result.getString("ename")
										+"����֤��" + result.getString("eid")
										+"�Ա�" + result.getString("esex")
										+"\t��¼״̬��" + result.getString("estate"));
				}} catch (ClassNotFoundException | SQLException e) {
				}
				break;
				
			case 2:
				System.out.println("��ȷ���޸Ŀ���ѧ�ţ�");
				String teqno = input.next();
				int count = 0;
				//�ж������Ƿ���ȷ
				for(String eno : enos){
					if( eno.equals(teqno) ){
						count++;
					}
				}
				//�����޸�
				if( count!=0){
					System.out.println("1.�޸�Ϊ���ѵ�¼��\t2.�޸�Ϊ��δ��¼��");
					String tchg = input.next();
					
					if(tchg.equals("1")){
						String sql = "update examinee set estate=\'�ѵ�¼\' where eno=\'?\'";
						try {
							dao.update(sql, teqno);
							System.out.println("1?");
						} catch (ClassNotFoundException | SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else if(tchg.equals("2")){
						
						String sql = "update examinee set estate=\'δ��¼\' where eno=\'?\'";
						try {
							dao.update(sql, teqno);
							System.out.println("2?");
						} catch (ClassNotFoundException | SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}else{
						System.out.println("���������ȷ�ϣ�");
					}
					
				}else{
					System.out.println("�ÿ��������ڣ���ȷ��");
				}
				break;
				
			case 3 :
				startLock.lock();
				//3��ʾ��ʼ����
				start = true;
				startCond.signalAll();
				startLock.unlock();
				break;
			}
		}
	 }


	public boolean isStart() {
		return start;
	}


	public void setStart(boolean start) {
		this.start = start;
	}


	public Lock getStartLock() {
		return startLock;
	}


	public void setStartLock(Lock startLock) {
		this.startLock = startLock;
	}


	public Condition getStartCond() {
		return startCond;
	}


	public void setStartCond(Condition startCond) {
		this.startCond = startCond;
	}
	
	
	
	
}
