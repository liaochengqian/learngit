package com.base.client;

public class AskQuestion extends ClientMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8752096800459496077L;
//		public boolean up = false;		//��һ��
//		public boolean down = false;	//��һ��
	public char num;
	//��������
	
	public AskQuestion( char num ){
		super.setType(2);
		this.num = num;
//		this.up = (num == '1' ) ? true : false ;
//		this.down = (num == '2' ) ? true : false ;
	}
		
}
