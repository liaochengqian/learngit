package com.base.client;

import java.io.Serializable;

public abstract class ClientMessage implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5896591253631663947L;
	private int type;
	/**
	 * 1-Login��
	 * 2-AskQuestion��
	 * 3-Answer��
	 * 4-Upload��
	 */
	//�޸����ͷ�����
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
}
