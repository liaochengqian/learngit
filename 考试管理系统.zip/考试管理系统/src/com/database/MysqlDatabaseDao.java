package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MysqlDatabaseDao {
	//1.�����ݿ��������
	/**
	 * ������ MysqlDatabaseDao ���������ݿ������
	 */
	//����������
	private String dbBaseURL;
	private String username;
	private String passwd;
	private Connection connection;
	private boolean close = false;
	
	//���幹�췽��
	public MysqlDatabaseDao(String dbBaseURL,String username,String passwd) {
		this.dbBaseURL = dbBaseURL;
		this.username = username;
		this.passwd = passwd;
	}
	
	//�������ӷ���
	public Connection getConnection() throws SQLException, ClassNotFoundException{
		if(connection == null){
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(dbBaseURL,username,passwd);
		}
		return connection;
	}
	//����رշ���
	public boolean getClose() throws SQLException{
		if(connection != null && !connection.isClosed()){
			connection.close();
			return close = true;
		}
		return !close;
	}
	
	//2.����Ԥ�������� ���ݿ���� �� ɾ �� ��
	//����Ԥ���뷽��
	//insert into - ����
	public boolean insert(String sql, Object ... parameters) 
								throws SQLException, ClassNotFoundException {
		PreparedStatement preparedStatement = getConnection().prepareStatement(sql);
		for (int i = 0; i < parameters.length; i++) {
			preparedStatement.setObject(i + 1, parameters[i]);
		}
		if (preparedStatement.executeUpdate() < 1) {
			return false;
		}
		return true;
	}
	//delete from -- ɾ��
	public boolean delete(String sql , Object...parameters) 
						throws SQLException, ClassNotFoundException{
		PreparedStatement preparedstatement = getConnection().prepareStatement(sql);
		for(int i=1 ; i<parameters.length; i++){
			preparedstatement.setObject(i, parameters[i-1]);
		}
		int judge = preparedstatement.executeUpdate();
		if(judge < 1){
			return false;
		}
		return true;
	}
	//update -- ����
	public boolean update(String sql , Object ... parameters) 
						throws SQLException, ClassNotFoundException{
		PreparedStatement preparedstatement = getConnection().prepareStatement(sql);
		for(int i=1 ; i<parameters.length; i++){
			preparedstatement.setObject(i, parameters[i-1]);
		}
		if(preparedstatement.executeUpdate() < 1){
			return false;
		}
		return true;
	}
	//select from --��ѯ
	public ResultSet select(String sql) 
			throws SQLException, ClassNotFoundException{
		Statement  statement = getConnection().createStatement();
		ResultSet result = statement.executeQuery(sql);
		return result;
	}

	//���������޸���
	public String getDbBaseURL() {
		return dbBaseURL;
	}

	public void setDbBaseURL(String dbBaseURL) {
		this.dbBaseURL = dbBaseURL;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public void setClose(boolean close) {
		this.close = close;
	}
}
