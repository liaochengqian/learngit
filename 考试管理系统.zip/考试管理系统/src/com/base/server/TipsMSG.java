package com.base.server;

public class TipsMSG extends ServerMessage {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2761641889982370797L;
	private String tips;
	//���췽��
	public TipsMSG( String tips ){
		super.setType(17);
		this.tips = tips;
	}
	
	@Override
	public String toString() {
		return "��ʾ��\t" + tips ;
	}
}
