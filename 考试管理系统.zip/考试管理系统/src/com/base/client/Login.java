package com.base.client;

public class Login extends ClientMessage {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4201424101833738587L;
	public String eno;
	public String epassword;
	public String eid;
	public String ename;

	public Login( String eno,String epassword,String eid,String ename){
		//��������
    	super.setType(3);
    	
		this.eno = eno;
		this.epassword = epassword;
		this.eid = eid;
		this.ename = ename;
	}
	
}
