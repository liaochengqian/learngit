package com.base.client;

public class Answer extends ClientMessage {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8342527282736223199L;
	public int qno;
    public int answerNum;  
    public String userAnswer;
	 
    public Answer(){
    	//��������
    	super.setType(1);
    	userAnswer = "δѡ��";
    }
    
	public Answer(int qno,int answerNum, String answerUser){
		  this.qno = qno; 
		  this.answerNum = answerNum;
		  this.userAnswer = answerUser;		 
	}
}
