package com.base.client;

public class TEST {
	
	public static void print( int[] arr){
		for(int r : arr){
			System.out.print(r);
		}
	}

	public static int[] getRandom( int num ){
		int[] r = new int[num];
		//�������
		for( int i=0 ; i< num ; i++){
			r[i] = i + 1;
		}
		//�������
		for( int i=0 ; i< num ; i++){
			int tmp = 0;
			int j = (int)( Math.random()*num );
			tmp = r[i];
			r[i] = r[j];
			r[j] = tmp;
		}
		return r;
	}
	
	
	
	
	public static void main(String[] args) {
		//AskQuestion ask = new AskQuestion();
	//	String eno = "123456";
		//System.out.println( "select * from examinee where eno= \'" + eno + "\'");
		print(getRandom(10));
	}

}
