package com.server;

import java.util.Deque;

public class SendListTask extends Thread {
	public Deque<Object> transList;
	public Object o;
	
	public SendListTask( Deque<Object> transList ){
		this.transList = transList;
	}
	
	@Override
	public void run(){
		if( transList.size() > 0 ){
			o = transList.removeFirst();
		}
	}
}
