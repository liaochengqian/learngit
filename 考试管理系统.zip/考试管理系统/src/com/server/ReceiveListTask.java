package com.server;

import java.util.Deque;

public class ReceiveListTask extends Thread {
	public Deque<Object> transList;
	public Object o;
	
	public ReceiveListTask( Deque<Object> transList , Object o ){
		this.transList = transList;
		this.o = o ;
	}
	
	@Override
	public void run(){
		transList.addLast(o);
	}
}
