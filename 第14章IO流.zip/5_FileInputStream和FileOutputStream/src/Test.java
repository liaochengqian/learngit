import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test {

	public static void main(String[] args) throws IOException {
		FileInputStream fis = new FileInputStream(".project");
		FileOutputStream fos = new FileOutputStream(".project2");
		/*
		// ʹ�ó����ṩ�Ļ�����
		byte[] buf = new byte[1024];
		int count = 0;
		while ((count = fis.read(buf)) > 0) {
			fos.write(buf, 0, count);
		}
		*/
		// ÿ�ζ�һ���ֽ�
		int c = -1;
		while ((c = fis.read()) > -1) {
			fos.write(c);
		}
		fos.close();
		fis.close();
	}

}
