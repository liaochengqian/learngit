import java.io.File;

public class DepthFirstTravel {
	private String dir;
	
	public DepthFirstTravel(String dir) {
		this.dir = dir;
	}
	
	public void travel() {
		File file = new File(dir);
		if (!file.exists()) {
			System.out.println(dir + " ������");
			return;
		}
		
		depthFirstTravel(dir, "");
	}
	
	private void depthFirstTravel(String dir, String prefix) {
		File file = new File(dir);
		System.out.println(prefix + file.getName() + (file.isDirectory() ? "(dir)": ""));
		if (file.isDirectory()) {  // ��Ŀ¼����
			String[] files = file.list();
			prefix += "  ";
			for (String f : files) {
				depthFirstTravel(dir + "/" + f, prefix);
			}
		}
	}
}
