import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TestScanner {

	public static void main(String[] args) throws FileNotFoundException {
		// Scanner ɨ������ɨ�� File ��������ʾ���ļ�
		File file = new File(".project1");
		Scanner input = new Scanner(file);
		System.out.println(input.nextLine());
		System.out.println(input.nextInt());
		System.out.println(input.nextDouble());
		System.out.println(input.nextBoolean());
	}

}
