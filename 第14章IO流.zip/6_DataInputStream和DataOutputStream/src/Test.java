import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test {

	public static void main(String[] args) throws IOException {
		// DataInputStream���DataOutputStream����Զ�д����������������
		// д���ļ�
		DataOutputStream dos = new DataOutputStream(new FileOutputStream("xxx.dat"));
		dos.writeByte(100);
		dos.writeDouble(2.5);
		dos.writeBoolean(true);
		dos.writeUTF("Hello world");
		dos.close();
		
		// ����
		DataInputStream dis = new DataInputStream(new FileInputStream("xxx.dat"));
		System.out.println(dis.readByte());
		System.out.println(dis.readDouble());
		System.out.println(dis.readBoolean());
		System.out.println(dis.readUTF());
	}

}
