package main;
import snake.Snake;
import com.bwf.jni.*;

public class SnakeGame {

	public static void main(String[] args) {
		
		String body = "◎";
		StringBuilder snake = new StringBuilder("❂◎◎◎◎♓");
		snake.insert(1,body);
		for(int i=0;i<snake.length();i++ ){
			Consoles.gotoXY(10, 10);
			System.out.print( snake.charAt(i) );
		}
	}
}
