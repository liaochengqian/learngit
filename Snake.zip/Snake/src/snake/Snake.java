package snake;
import java.util.ArrayList;

import com.bwf.jni.Consoles;
import com.bwf.jni.Consoles.Position;
public class Snake {
	private final String HEAD = "❂";
	private final String END = "♓  ";
	private final String BODY = "◎";
	StringBuilder snake = new StringBuilder("❂◎◎♓  ");
	//private double speed = 500 ;
	//private double speedUp = 50;
	//private int range;
	
	//private int[][] position = new int[range][range];
	
	//private boolean isAlive = true;
	private boolean left=false,right=false,up=false,down=false;
	ArrayList<Position> position = new ArrayList<Position>();
	
	//Deque<Position>
	
	
	//private String snake;
	//private int length = snake.length();
	
	//snake的形状
//	public Snake(){
	//	this.snake = HEAD + body + END ;
	//}
	//构造方法
	//public Snake( int[][] position , double speed ){
		//this.position = position ;
		//this.speed = speed;
	//}
	
	
	//保存蛇的初始坐标
	public void snakePosition(int x,int y){
		for( int i =0 ; i<snake.length(); i++){
				position.add( new Position( x+i,y ) );
		}
	}

	//根据Arraylist中的位置数据打印蛇
	public void printSnake(){
		for( int i =0 ; i<position.size() ; i++){
			Consoles.gotoXY( position.get(i).x, position.get(i).y);
			if(i == 0){
				System.out.print( HEAD );
			}else if(i == ( position.size() - 1)){
				System.out.print( END );
			}else{
				System.out.print( BODY );
			}
		}
	}
	
	//定义蛇的按键移动情况
	public void keyMove( int direction ){
		while(true){
			//1.定义上下左右的移动方法
			//2.在方向没有被打断前，snake不会跳出移动循环
			switch( direction ){
			case Consoles.UP:
								up = true;
								snakeUp(up);
								break;
			case Consoles.DOWN:
								down = true;
								snakeDown(down);
								break;
			case Consoles.LEFT:
								left = true;
								snakeLeft(left);
								break;
			case Consoles.RIGHT:
								right = true;
								snakeRight(right);
								break;
			}
			printSnake();
		}
	}
	

	//蛇的移动坐标——向左
	public void snakeLeft( boolean left){
		if( left ){
			for(int i=snake.length()-1;i>0;i--){
				position.set(i, position.get(i-1));
			}
			
			int firstX = position.get(0).x;
			int firstY = position.get(0).y;
			position.add(0, new Position(firstX-1 , firstY) );
		}
	}
	//蛇的移动坐标——向右
		public void snakeRight( boolean right){
			if( right ){
				for(int i=snake.length()-1;i>0;i--){
					position.set(i, position.get(i-1));
				}
				
				int firstX = position.get(0).x;
				int firstY = position.get(0).y;
				position.add(0, new Position(firstX+1 , firstY) );
			}
		}
		//蛇的移动坐标——向上
		public void snakeUp( boolean up){
			if( up ){
				for(int i=snake.length()-1;i>0;i--){
					position.set(i, position.get(i-1));
				}
				
				int firstX = position.get(0).x;
				int firstY = position.get(0).y;
				position.add(0, new Position(firstX , firstY-1) );
			}
		}
		
		//蛇的移动坐标——向下
		public void snakeDown( boolean down){
			if( down ){
				for(int i=snake.length()-1;i>0;i--){
					position.set(i, position.get(i-1));
				}
				
				int firstX = position.get(0).x;
				int firstY = position.get(0).y;
				position.add(0, new Position(firstX , firstY-1) );
			}
		}
	
	//吃东西
	public void eatFood( int foodX , int foodY){
		//判断是否吃到食物
		if( position.get(0).x == foodX && position.get(0).y == foodY){ //吃到
			snake.insert( 1 , BODY );
		
			for(int i=snake.length()-1;i>0;i--){
				position.set(i, position.get(i-1));
			}
			position.set(0 , new Position(foodX , foodY) );
		}
	}	
	
	//判断是否吃到了自己
	public boolean isEatSelf(int x, int y) {
		for (int i =0; i<position.size()-1 ;i++) {
			Position p = position.get(i);
			if (p.x == x && p.y == y) {		
				return true;
			}
		}
	return false;	
	}
}
