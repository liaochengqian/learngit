
class Consoles {
	static {
		System.loadLibrary("consoles");
	}
	
	public static native void gotoxy(int x, int y);
}
