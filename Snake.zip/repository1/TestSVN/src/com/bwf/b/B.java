package com.bwf.b;

public class B {
	public B() {
		
	}
}
