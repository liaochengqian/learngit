package com.bwf.a;

import com.bwf.b.B;
import com.bwf.c.C;

public class Test {

	public static void main(String[] args) {
		B b = new B();
		C c = new C(2);
	}
}
