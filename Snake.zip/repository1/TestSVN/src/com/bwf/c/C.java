package com.bwf.c;

public class C {
	int c;
	public C(int c) {
		this.c = c;
	}
}
