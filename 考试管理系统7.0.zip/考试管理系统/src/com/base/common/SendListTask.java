package com.base.common;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Deque;

public class SendListTask extends Thread {
	public Deque<Object> transList;
	public Object o;
	public ObjectOutputStream oos;
	
	public SendListTask( Deque<Object> transList ,ObjectOutputStream oos ){
		this.transList = transList;
		this.oos = oos;
	}
	
	@Override
	public void run(){
		while( true ){
			if( transList.size() > 0 ){
				o = transList.removeFirst();
				//������o������������
				try {
					oos.writeObject( o );
					oos.flush();
					notifyAll(); //֪ͨ���̻߳�ȡ
					Thread.sleep(500);
					
				} catch (IOException e) {
					//�ر������
					try {
						oos.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}

				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			}	
		}
	}
}
