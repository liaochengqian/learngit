package com.base.common;

import java.io.IOException;
import java.io.ObjectInputStream;

public class ReceiveListTask extends Thread {
	public Object o;
	public ObjectInputStream ois;
	
	public ReceiveListTask( ObjectInputStream ois ){
		this.ois = ois ;
	}
	
	@Override
	public void run(){
		Object object = null;
		try {
			
			while( (object = ois.readObject()) != null ){
				this.o = object ;			 //�����н��ն���
				wait();						//�û���ɲ������ٻ�ȡ��һ��
			}
				
		} catch (ClassNotFoundException | IOException | InterruptedException e) {
			//�ر�������
			try {
				ois.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		
	}
}
