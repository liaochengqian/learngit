package com.base.client;

public class Upload extends ClientMessage{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7296646449679937703L;
	
	//��������
	public Upload(){
		super.setType(4);
	}             		
}
