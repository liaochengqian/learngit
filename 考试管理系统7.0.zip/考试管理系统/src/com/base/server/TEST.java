package com.base.server;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import com.database.MysqlDatabaseDao;
import com.server.*;


public class TEST {
	/*
	public static int[] getAnswerNo( int accountSum ) {
		
	int[] answerNos = new int[ accountSum ];
	
	for( int i = 0 ; i < accountSum ; i++){
		int count = 0;
		while( true ){
			int tmp = ( 1 + (int)(Math.random()*accountSum) );
			for( int an : answerNos ){
				if( an == answerNos[i] ){
					count++;
				}
			}
			if(count == 0){
				answerNos[i] = tmp;
				break;
			}
		}
	}
	return answerNos;
	}
	*/
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
/*
		LoginPass pl = new LoginPass(60, 100, 100, "E:\\��ҵ\\���Թ���ϵͳ\\�ϻ����Կ�������.txt" );
		System.out.println( pl );
	}
	
	*/
		String URL = "jdbc:mysql://localhost/";
		//String URL = "jdbc:mysql://172.31.148.90/";
		String dbBase = "examinationmanagement";
		String dbBaseURL = URL + dbBase;
		String username = "root";
		String passwd = "";
		//��������
		MysqlDatabaseDao dao = new MysqlDatabaseDao(dbBaseURL, username, passwd);
		//Student st = new Student("2016080012", dao);
		//dao.getConnection();
		//QuestionBase qbase = new QuestionBase(10, 100, dao);
		//SendQuestion sq = new SendQuestion();
		//SendQuestion.Question qb = sq.new Question( 7 , dao);
		//sq = new SendQuestion( 6 , qb );
		dao.getConnection();
		
		/*
		 * String sql = "insert into answersheet (ano,aqno,aano,aanswers) "
							+ "values (?,?,?,?)";
					String sql = "update answersheet set aqno=?"
								+ ", set aanswer=?"  
								+ " where ano=?"  
								+ " and aano =?";
					dao.update(sql, ans.qno, ans.userAnswer, login.eno, ans.answerNum);
		 */
		//String sql = "insert into answersheet (ano,aqno,aano,aanswers) "
		//			+ "values (?,?,?,?)";
		//dao.insert(sql , "2016080012" ,3 , 5, "ABCD" );
	
					answerSheet sql = new answerSheet("2016080012", dao);
		System.out.println(sql);
		
	//	SendQuestion sendQ = new SendQuestion( 1 , qbase );
		//Question sq = new Question( 2 , dao);
		
		//sq.setUserAnswer( "C" );
		//System.out.println(sq + "\n��׼��"  );
	}
	
}
	
	
	//����������������/˳��ļ��ϣ�������

	/*
	int[] asn =	getAnswerNo( 6 );
	for(int its : asn){
		System.out.print( its + "\t");
	}
	*/