package com.base.server;

public class LoginFail extends ServerMessage {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6120409395445054976L;
	private String reason;
	
	public LoginFail(){
		super.setType(12);
	}

	@Override
	public String toString() {
		return "��½ʧ�ܣ���˶Ժ��������룺" ;
	}

}
