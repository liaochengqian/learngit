package hano.base;

public class DishSizeException extends RuntimeException {
	private int size;
	
	public DishSizeException(int size) {
		super("Υ����С�´�Ĺ���size = " + size);
		this.size = size;
	}

	public int getSize() {
		return size;
	}

}
